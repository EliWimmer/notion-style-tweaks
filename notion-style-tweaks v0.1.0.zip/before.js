// this code will be executed before page load
(function() {
  console.log('before.js executed');
})();
