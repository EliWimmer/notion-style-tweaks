# Notion Style Tweaker (Beta)

NST is a free and open source Chrome extension that allows you to tweak the style of your Notion pages. It is currently a work in progress and is currently in beta.

If you find any bugs or have any suggestions feel free to open an issue.
